# Minal's Birthday Surprise Website

A romantic, responsive birthday website starter for Minal — made by Darshan.

## Personalise it with your media
Replace the placeholder files with your own media, keeping these filenames:
- `assets/photos/cover.jpg` — Minal's favourite portrait/photo
- `assets/photos/photo-01.jpg` through `photo-24.jpg` — your photo gallery (20–30 photos can be added; add more files and gallery slots as needed)
- `assets/photos/satara-cover.jpg`, `satara-01.jpg`, `satara-02.jpg`, `satara-03.jpg` — first-trip-to-Satara memories
- `assets/videos/memory-01.mp4` through `memory-04.mp4` — your short videos
- `assets/music/our-song.mp3` — the exact birthday song/audio you choose

The current page shows visual placeholders until you add your photos/videos. The music button starts playback only after the visitor taps it (browser autoplay rules).

## Publish on GitHub Pages
1. Sign in to GitHub and create a **public** repository named `minal-birthday-surprise`.
2. Upload `index.html`, `style.css`, `script.js`, and the `assets` folder to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main**, folder **/(root)**, then Save.
6. Wait for GitHub Pages to publish. Your link will look like:
   `https://YOUR-GITHUB-USERNAME.github.io/minal-birthday-surprise/`

## Important
GitHub Pages sites are public. Anyone with the link may view the site. Only upload photos/videos you are both comfortable sharing. Do not upload private or intimate material, and do not share your GitHub password or recovery codes.
